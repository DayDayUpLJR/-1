/*
Navicat MySQL Data Transfer

Source Server         : xinye
Source Server Version : 80035
Source Host           : localhost:3306
Source Database       : res

Target Server Type    : MYSQL
Target Server Version : 80035
File Encoding         : 65001

Date: 2024-01-05 15:23:21
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for address_management
-- ----------------------------
DROP TABLE IF EXISTS `address_management`;
CREATE TABLE `address_management` (
  `usid` int NOT NULL,
  `adid` int NOT NULL AUTO_INCREMENT,
  `username` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT NULL,
  `address` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT NULL,
  `detailed_address` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT NULL,
  `tel` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT NULL,
  `landline_telephone` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT NULL,
  `isdefault` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT NULL,
  `alias` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT NULL,
  PRIMARY KEY (`adid`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;

-- ----------------------------
-- Records of address_management
-- ----------------------------
INSERT INTO `address_management` VALUES ('1', '15', '张三', '河北省秦皇岛市抚宁区', '衡阳市', '19976650042', '19158117413', '257160660@qq.com', '1', '家里');
INSERT INTO `address_management` VALUES ('1', '16', '张三', '山西省阳泉市矿区', '衡阳市', '19976650042', '19158117413', '257160660@qq.com', '0', '父母家');
INSERT INTO `address_management` VALUES ('1', '18', '张三', '天津市市辖区河西区', '衡阳市', '19976650042', '19158117413', '257160660@qq.com', '0', '公司');
INSERT INTO `address_management` VALUES ('1', '19', '张三', '内蒙古自治区赤峰市元宝山区', '衡阳市', '19976650042', '19158117413', '257160660@qq.com', '0', '公司');
INSERT INTO `address_management` VALUES ('2', '20', '李四', '天津市市辖区和平区', '衡阳市', '19976650042', '19158117413', '257160660@qq.com', '1', '家里');

-- ----------------------------
-- Table structure for resadmin
-- ----------------------------
DROP TABLE IF EXISTS `resadmin`;
CREATE TABLE `resadmin` (
  `raid` int NOT NULL AUTO_INCREMENT,
  `raname` varchar(50) COLLATE utf8mb4_bin DEFAULT NULL,
  `rapwd` varchar(150) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`raid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

-- ----------------------------
-- Records of resadmin
-- ----------------------------
INSERT INTO `resadmin` VALUES ('1', 'a', '0cc175b9c0f1b6a831c399e269772661');

-- ----------------------------
-- Table structure for reschat
-- ----------------------------
DROP TABLE IF EXISTS `reschat`;
CREATE TABLE `reschat` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '编号',
  `content` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT NULL COMMENT '消息',
  `fromuser` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT NULL COMMENT '发送者',
  `touser` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT NULL COMMENT '接收者',
  `type` varchar(10) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT NULL COMMENT '消息类型',
  `time` datetime DEFAULT NULL COMMENT '时间',
  `readed` int DEFAULT NULL COMMENT '是否已读',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=76 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of reschat
-- ----------------------------
INSERT INTO `reschat` VALUES ('66', 'as', 'a', '小萌神客服', 'text', '2024-01-04 16:13:56', '1');
INSERT INTO `reschat` VALUES ('67', 'asdf', '小萌神客服', 'a', 'text', '2024-01-04 16:20:35', '1');
INSERT INTO `reschat` VALUES ('68', 'asdf', '小萌神客服', 'a', 'text', '2024-01-04 16:20:35', '1');
INSERT INTO `reschat` VALUES ('69', 'asd', '小萌神客服', 'a', 'text', '2024-01-04 16:21:16', '1');
INSERT INTO `reschat` VALUES ('70', 'asd', '小萌神客服', 'a', 'text', '2024-01-04 16:21:16', '1');
INSERT INTO `reschat` VALUES ('71', 'asxc', 'a', '小萌神客服', 'text', '2024-01-04 16:22:33', '1');
INSERT INTO `reschat` VALUES ('72', 'asxc', 'a', '小萌神客服', 'text', '2024-01-04 16:22:33', '1');
INSERT INTO `reschat` VALUES ('73', '我是用户a', 'a', '小萌神客服', 'text', '2024-01-05 13:52:39', '1');
INSERT INTO `reschat` VALUES ('74', '我是用户b', 'b', '小萌神客服', 'text', '2024-01-05 14:33:52', '1');
INSERT INTO `reschat` VALUES ('75', '我是用户b', 'b', '小萌神客服', 'text', '2024-01-05 14:33:52', '1');

-- ----------------------------
-- Table structure for resfood
-- ----------------------------
DROP TABLE IF EXISTS `resfood`;
CREATE TABLE `resfood` (
  `fid` int NOT NULL AUTO_INCREMENT,
  `fname` varchar(50) COLLATE utf8mb4_bin DEFAULT NULL,
  `normprice` decimal(8,2) DEFAULT NULL,
  `realprice` decimal(8,2) DEFAULT NULL,
  `detail` varchar(2000) COLLATE utf8mb4_bin DEFAULT NULL,
  `fphoto` varchar(1000) COLLATE utf8mb4_bin DEFAULT NULL,
  `status` varchar(50) COLLATE utf8mb4_bin DEFAULT '0',
  PRIMARY KEY (`fid`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

-- ----------------------------
-- Records of resfood
-- ----------------------------
INSERT INTO `resfood` VALUES ('1', '素炒莴笋丝', '22.00', '20.00', '营养丰富', 'group1/M00/00/00/rBIABWVOCvqARXgGAAOA1dwT4AY539.jpg', '0');
INSERT INTO `resfood` VALUES ('2', '蛋炒饭', '22.00', '20.00', '营养丰富', 'group1/M00/00/00/rBIABWVOCvqARXgGAAOA1dwT4AY539.jpg', '0');
INSERT INTO `resfood` VALUES ('3', '酸辣鱼', '42.00', '40.00', '营养丰富', 'group1/M00/00/00/rBIABWVOCvqARXgGAAOA1dwT4AY539.jpg', '0');
INSERT INTO `resfood` VALUES ('4', '鲁粉', '12.00', '10.00', '营养丰富', 'group1/M00/00/00/rBIABWVOCvqARXgGAAOA1dwT4AY539.jpg', '0');
INSERT INTO `resfood` VALUES ('5', '西红柿蛋汤', '12.00', '10.00', '营养丰富', 'group1/M00/00/00/rBIABWVOCvqARXgGAAOA1dwT4AY539.jpg', '0');
INSERT INTO `resfood` VALUES ('6', '炖鸡', '12.00', '100.00', '营养丰富', 'group1/M00/00/00/rBIABWVOCvqARXgGAAOA1dwT4AY539.jpg', '0');
INSERT INTO `resfood` VALUES ('7', '炒鸡', '12.00', '10.00', '营养丰富', 'group1/M00/00/00/rBIABWVOCvqARXgGAAOA1dwT4AY539.jpg', '0');
INSERT INTO `resfood` VALUES ('8', '炒饭', '12.00', '10.00', '营养丰富', 'group1/M00/00/00/rBIABWVOCvqARXgGAAOA1dwT4AY539.jpg', '0');
INSERT INTO `resfood` VALUES ('9', '手撕前女友', '12.00', '10.00', '营养丰富', 'group1/M00/00/00/rBIABWVOCvqARXgGAAOA1dwT4AY539.jpg', '1');
INSERT INTO `resfood` VALUES ('10', '面条', '12.00', '10.00', '营养丰富', 'group1/M00/00/00/rBIABWVOCvqARXgGAAOA1dwT4AY539.jpg', '1');
INSERT INTO `resfood` VALUES ('11', '端菜', '12.00', '10.00', '营养丰富', 'group1/M00/00/00/rBIABWVOCvqARXgGAAOA1dwT4AY539.jpg', '0');
INSERT INTO `resfood` VALUES ('12', '酸豆角', '12.00', '10.00', '营养丰富', 'group1/M00/00/00/rBIABWVOCvqARXgGAAOA1dwT4AY539.jpg', '0');
INSERT INTO `resfood` VALUES ('13', '新菜品', '20.00', '10.00', '好吃...', 'group1/M00/00/00/rBIABWVOCvqARXgGAAOA1dwT4AY539.jpg', '0');
INSERT INTO `resfood` VALUES ('14', '新菜品', '200.00', '100.00', '好吃...', 'group1/M00/00/00/rBIABWVOCvqARXgGAAOA1dwT4AY539.jpg', '0');
INSERT INTO `resfood` VALUES ('15', '新菜品', '20.00', '100.00', '好吃...', 'group1/M00/00/00/rBIABWVOCvqARXgGAAOA1dwT4AY539.jpg', '0');
INSERT INTO `resfood` VALUES ('16', '新菜品', '200.00', '10.00', '好吃...', 'group1/M00/00/00/rBIABWVOCvqARXgGAAOA1dwT4AY539.jpg', '1');
INSERT INTO `resfood` VALUES ('25', 'ws', '20.00', '10.00', '好吃...', 'group1/M00/00/00/rBIABWVOCvqARXgGAAOA1dwT4AY539.jpg', '1');
INSERT INTO `resfood` VALUES ('26', 'ws', '20.00', '10.00', '好吃112', 'group1/M00/00/00/rBIABWVOCvqARXgGAAOA1dwT4AY539.jpg', '1');

-- ----------------------------
-- Table structure for resorder
-- ----------------------------
DROP TABLE IF EXISTS `resorder`;
CREATE TABLE `resorder` (
  `roid` int NOT NULL AUTO_INCREMENT,
  `userid` int DEFAULT NULL,
  `address` varchar(500) COLLATE utf8mb4_bin DEFAULT NULL,
  `tel` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `ordertime` datetime DEFAULT NULL,
  `deliverytime` datetime DEFAULT NULL,
  `ps` varchar(2000) COLLATE utf8mb4_bin DEFAULT NULL,
  `status` int DEFAULT NULL,
  `stars` varchar(10) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '评分',
  `detailed_address` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `username` varchar(20) COLLATE utf8mb4_bin DEFAULT NULL,
  `discount` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`roid`),
  KEY `fk_resorder` (`userid`),
  CONSTRAINT `fk_resorder` FOREIGN KEY (`userid`) REFERENCES `resuser` (`userid`)
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

-- ----------------------------
-- Records of resorder
-- ----------------------------
INSERT INTO `resorder` VALUES ('3', '1', '湖南工学院', '12345678910', '2023-11-24 21:21:48', '2023-11-24 21:11:48', '快快', '3', '4', '湖工', '张三', '3.00');
INSERT INTO `resorder` VALUES ('4', '1', '湖南工学院', '12345678910', '2023-11-24 20:22:48', '2023-11-24 20:11:48', '快快', '0', '3', '湖工', '张三', null);
INSERT INTO `resorder` VALUES ('5', '1', '2331', '122323', '2023-03-28 11:39:48', '2023-03-28 11:19:48', 'kk', '2', '2', '湖工', '张三', null);
INSERT INTO `resorder` VALUES ('6', '1', '23', '122323', '2023-04-28 22:31:48', '2023-04-28 22:21:48', 'kk', '0', '1', '湖工', '张三', null);
INSERT INTO `resorder` VALUES ('7', '1', '233', '122323', '2023-05-28 21:52:48', '2023-05-28 21:31:48', 'kk', '4', '1', '湖工', '张三', null);
INSERT INTO `resorder` VALUES ('8', '1', '231', '122323', '2023-06-28 21:51:48', '2023-06-28 21:31:48', 'kk', '3', '5', '湖工', '张三', null);
INSERT INTO `resorder` VALUES ('9', '2', '2311', '122323', '2023-07-28 00:00:00', '2023-07-28 00:00:00', 'kk', '3', '3', '湖工', '张三', null);
INSERT INTO `resorder` VALUES ('10', '3', '2313', '122323', '2023-08-28 00:00:00', '2023-08-28 00:00:00', 'kk', '3', '4', '湖工', '张三', null);
INSERT INTO `resorder` VALUES ('13', '1', '231', '122323', '2023-11-28 00:00:00', '2023-11-28 00:00:00', 'kk', '3', '5', '湖工', '张三', '4.00');
INSERT INTO `resorder` VALUES ('15', '2', '湖南工学院', '122324', '2022-11-29 00:00:00', '2023-11-29 00:00:00', 'll', '3', '5', '湖工', '张三', null);
INSERT INTO `resorder` VALUES ('16', '3', '湖南工学院', '122325', '2022-10-30 00:00:00', '2022-10-30 00:00:00', 'mm', '3', '5', '湖工', '张三', null);
INSERT INTO `resorder` VALUES ('17', '1', '湖南工学院', '122326', '2023-11-08 00:00:00', '2023-11-08 00:00:00', 'nn', '3', '5', '湖工', '张三', '12.00');
INSERT INTO `resorder` VALUES ('18', '1', '湖南工学院', '122327', '2022-01-01 00:00:00', '2022-01-01 00:00:00', 'oo', '3', '5', '湖工', '张三', null);
INSERT INTO `resorder` VALUES ('19', '2', '湖南工学院', '122328', '2022-02-02 00:00:00', '2022-02-02 00:00:00', 'pp', '3', '5', '湖工', '张三', null);
INSERT INTO `resorder` VALUES ('20', '2', '湖工', '122329', '2022-03-03 00:00:00', '2022-03-03 00:00:00', 'qq', '3', '5', '湖工', '张三', null);
INSERT INTO `resorder` VALUES ('21', '2', '湖工', '122330', '2022-04-04 00:00:00', '2022-04-04 00:00:00', 'rr', '3', '3', '湖工', '张三', null);
INSERT INTO `resorder` VALUES ('22', '3', '湖工', '122331', '2022-05-05 00:00:00', '2022-05-05 00:00:00', 'ss', '3', '2', '湖工', '张三', null);
INSERT INTO `resorder` VALUES ('23', '1', '湖工', '122323', '2022-06-28 00:00:00', '2022-06-28 00:00:00', 'kk', '3', '5', '湖工', '张三', null);
INSERT INTO `resorder` VALUES ('24', '3', '湖工', '122332', '2022-07-06 00:00:00', '2022-07-06 00:00:00', 'tt', '3', '4', '湖工', '张三', null);
INSERT INTO `resorder` VALUES ('25', '2', '湖南工学院', '122324', '2021-08-29 00:00:00', '2021-08-29 00:00:00', 'll', '3', '5', '湖工', '张三', null);
INSERT INTO `resorder` VALUES ('26', '3', '湖南工学院', '122325', '2021-09-30 00:00:00', '2021-09-30 00:00:00', 'mm', '3', '5', '湖工', '张三', null);
INSERT INTO `resorder` VALUES ('27', '1', '湖南工学院', '122326', '2021-10-31 00:00:00', '2021-10-31 00:00:00', 'nn', '3', '5', '湖工', '张三', null);
INSERT INTO `resorder` VALUES ('28', '1', '湖南工学院', '122327', '2021-01-01 00:00:00', '2021-01-01 00:00:00', 'oo', '3', '4', '湖工', '张三', null);
INSERT INTO `resorder` VALUES ('29', '2', '湖南工学院', '122328', '2021-02-02 00:00:00', '2022-01-02 00:00:00', 'pp', '3', '3', '湖工', '张三', null);
INSERT INTO `resorder` VALUES ('30', '2', '湖工', '122329', '2021-03-03 00:00:00', '2021-03-03 00:00:00', 'qq', '3', '3', '湖工', '张三', null);
INSERT INTO `resorder` VALUES ('31', '2', '湖工', '122330', '2021-04-04 00:00:00', '2021-04-04 00:00:00', 'rr', '3', '3', '湖工', '张三', null);
INSERT INTO `resorder` VALUES ('32', '3', '湖工', '122331', '2021-05-05 00:00:00', '2021-05-05 00:00:00', 'ss', '3', '3', '湖工', '张三', null);
INSERT INTO `resorder` VALUES ('33', '1', '湖工', '122323', '2021-06-28 00:00:00', '2021-06-28 00:00:00', 'kk', '3', '5', '湖工', '张三', null);
INSERT INTO `resorder` VALUES ('34', '3', '湖工', '122332', '2021-07-06 00:00:00', '2021-07-06 00:00:00', 'tt', '3', '4', '湖工', '张三', null);
INSERT INTO `resorder` VALUES ('35', '2', '湖院', '122324', '2020-08-29 00:00:00', '2020-08-29 00:00:00', 'll', '3', '5', '湖工', '张三', null);
INSERT INTO `resorder` VALUES ('36', '3', '湖院', '1225', '2020-12-30 00:00:00', '2020-12-30 00:00:00', 'mm', '3', '5', '湖工', '张三', null);
INSERT INTO `resorder` VALUES ('37', '1', '湖院', '126', '2020-10-31 00:00:00', '2020-10-31 00:00:00', 'nn', '3', '5', '湖工', '张三', null);
INSERT INTO `resorder` VALUES ('38', '1', '湖院', '1227', '2020-01-01 00:00:00', '2020-01-01 00:00:00', 'oo', '3', '4', '湖工', '张三', null);
INSERT INTO `resorder` VALUES ('39', '2', '湖学院', '1228', '2020-03-02 00:00:00', '2020-03-02 00:00:00', 'pp', '3', '3', '湖工', '张三', null);
INSERT INTO `resorder` VALUES ('40', '2', '湖工', '1229', '2020-04-03 00:00:00', '2020-04-03 00:00:00', 'qq', '3', '3', '湖工', '张三', null);
INSERT INTO `resorder` VALUES ('41', '2', '湖工', '1230', '2020-05-04 00:00:00', '2020-05-04 00:00:00', 'rr', '3', '3', '湖工', '张三', null);
INSERT INTO `resorder` VALUES ('42', '3', '湖工', '1231', '2020-06-05 00:00:00', '2020-06-05 00:00:00', 'ss', '3', '3', '湖工', '张三', null);
INSERT INTO `resorder` VALUES ('43', '1', '湖工', '1223', '2020-11-28 00:00:00', '2020-11-28 00:00:00', 'kk', '3', '5', '湖工', '张三', null);
INSERT INTO `resorder` VALUES ('44', '3', '湖工', '12', '2020-07-06 00:00:00', '2020-07-06 00:00:00', 'tt', '3', '4', '湖工', '张三', null);
INSERT INTO `resorder` VALUES ('45', '2', '湖院', '122324', '2019-12-29 00:00:00', '2019-12-29 00:00:00', 'll', '3', '5', '湖工', '张三', null);
INSERT INTO `resorder` VALUES ('46', '3', '湖院', '1225', '2019-11-30 00:00:00', '2019-11-30 00:00:00', 'mm', '3', '5', '湖工', '张三', null);
INSERT INTO `resorder` VALUES ('47', '1', '湖院', '126', '2019-10-31 00:00:00', '2019-10-31 00:00:00', 'nn', '3', '5', '湖工', '张三', null);
INSERT INTO `resorder` VALUES ('48', '1', '湖院', '1227', '2019-01-01 00:00:00', '2019-01-01 00:00:00', 'oo', '3', '4', '湖工', '张三', null);
INSERT INTO `resorder` VALUES ('49', '2', '湖学院', '1228', '2019-02-02 00:00:00', '2019-02-02 00:00:00', 'pp', '3', '3', '湖工', '张三', null);
INSERT INTO `resorder` VALUES ('50', '2', '湖工', '1229', '2019-03-03 00:00:00', '2019-03-03 00:00:00', 'qq', '3', '3', '湖工', '张三', null);
INSERT INTO `resorder` VALUES ('51', '2', '湖工', '1230', '2019-04-04 00:00:00', '2019-04-04 00:00:00', 'rr', '3', '3', '湖工', '张三', null);
INSERT INTO `resorder` VALUES ('52', '3', '湖工', '1231', '2019-05-05 00:00:00', '2019-05-05 00:00:00', 'ss', '3', '3', '湖工', '张三', null);
INSERT INTO `resorder` VALUES ('53', '1', '湖工', '1223', '2019-06-28 00:00:00', '2019-07-28 00:00:00', 'kk', '3', '5', '湖工', '张三', null);
INSERT INTO `resorder` VALUES ('54', '3', '湖工', '12', '2019-09-06 00:00:00', '2019-09-06 00:00:00', 'tt', '3', '4', '湖工', '张三', null);
INSERT INTO `resorder` VALUES ('56', '1', '河北省秦皇岛市抚宁区', '19976650042', '2024-01-04 22:52:14', '2024-01-04 23:52:14', '', '0', null, '衡阳市', '张三', null);
INSERT INTO `resorder` VALUES ('57', '1', '河北省秦皇岛市抚宁区', '19976650042', '2024-01-05 00:45:45', '2024-01-05 01:45:45', '', '0', null, '衡阳市', '张三', null);
INSERT INTO `resorder` VALUES ('58', '1', '湖院', '122324', '2023-12-29 00:00:00', '2023-12-29 00:00:00', 'll', '0', '0', '湖工', '张三', '5.00');
INSERT INTO `resorder` VALUES ('59', '1', '湖院', '1225', '2023-11-30 00:00:00', '2023-11-30 00:00:00', 'mm', '3', '3', '湖工', '张三', '10.00');
INSERT INTO `resorder` VALUES ('60', '1', '湖院', '126', '2023-10-31 00:00:00', '2023-10-31 00:00:00', 'nn', '3', '2', '湖工', '张三', '5.00');
INSERT INTO `resorder` VALUES ('61', '1', '河北省秦皇岛市抚宁区', '19976650042', '2024-01-05 14:30:47', '2024-01-05 15:30:47', 'sd', '1', null, '衡阳市', '张三', '0.52');
INSERT INTO `resorder` VALUES ('62', '2', '天津市市辖区和平区', '19976650042', '2024-01-05 14:36:51', '2024-01-05 15:36:51', '快快2', '1', null, '衡阳市', '李四', '1.00');

-- ----------------------------
-- Table structure for resorderitem
-- ----------------------------
DROP TABLE IF EXISTS `resorderitem`;
CREATE TABLE `resorderitem` (
  `roiid` int NOT NULL AUTO_INCREMENT,
  `roid` int DEFAULT NULL,
  `fid` int DEFAULT NULL,
  `dealprice` decimal(8,2) DEFAULT NULL,
  `num` int DEFAULT NULL,
  PRIMARY KEY (`roiid`),
  KEY `fk_resorderitem_roid` (`roid`),
  KEY `fk_tbl_res_fid` (`fid`),
  CONSTRAINT `fk_resorderitem_roid` FOREIGN KEY (`roid`) REFERENCES `resorder` (`roid`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tbl_res_fid` FOREIGN KEY (`fid`) REFERENCES `resfood` (`fid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

-- ----------------------------
-- Records of resorderitem
-- ----------------------------
INSERT INTO `resorderitem` VALUES ('3', '3', '14', '20.00', '2');
INSERT INTO `resorderitem` VALUES ('7', '4', '13', '21.00', '2');
INSERT INTO `resorderitem` VALUES ('8', '6', '12', '12.00', '2');
INSERT INTO `resorderitem` VALUES ('9', '4', '11', '34.00', '2');
INSERT INTO `resorderitem` VALUES ('10', '4', '10', '33.00', '2');
INSERT INTO `resorderitem` VALUES ('11', '7', '12', '22.00', '2');
INSERT INTO `resorderitem` VALUES ('12', '8', '11', '20.00', '2');
INSERT INTO `resorderitem` VALUES ('13', '9', '10', '23.00', '2');
INSERT INTO `resorderitem` VALUES ('14', '10', '3', '44.00', '2');
INSERT INTO `resorderitem` VALUES ('17', '13', '16', '23.00', '2');
INSERT INTO `resorderitem` VALUES ('19', '15', '15', '25.00', '3');
INSERT INTO `resorderitem` VALUES ('20', '16', '2', '30.00', '4');
INSERT INTO `resorderitem` VALUES ('21', '17', '16', '35.00', '5');
INSERT INTO `resorderitem` VALUES ('22', '18', '1', '40.00', '6');
INSERT INTO `resorderitem` VALUES ('23', '19', '2', '45.00', '7');
INSERT INTO `resorderitem` VALUES ('24', '20', '3', '50.00', '8');
INSERT INTO `resorderitem` VALUES ('25', '21', '4', '55.00', '9');
INSERT INTO `resorderitem` VALUES ('26', '22', '11', '60.00', '10');
INSERT INTO `resorderitem` VALUES ('27', '23', '12', '65.00', '11');
INSERT INTO `resorderitem` VALUES ('28', '24', '14', '20.00', '2');
INSERT INTO `resorderitem` VALUES ('29', '25', '15', '25.00', '3');
INSERT INTO `resorderitem` VALUES ('30', '26', '2', '30.00', '4');
INSERT INTO `resorderitem` VALUES ('31', '27', '1', '35.00', '5');
INSERT INTO `resorderitem` VALUES ('32', '28', '1', '40.00', '6');
INSERT INTO `resorderitem` VALUES ('33', '29', '2', '45.00', '7');
INSERT INTO `resorderitem` VALUES ('34', '20', '3', '50.00', '8');
INSERT INTO `resorderitem` VALUES ('35', '21', '4', '55.00', '9');
INSERT INTO `resorderitem` VALUES ('36', '22', '11', '60.00', '10');
INSERT INTO `resorderitem` VALUES ('37', '23', '12', '65.00', '11');
INSERT INTO `resorderitem` VALUES ('38', '24', '14', '20.00', '2');
INSERT INTO `resorderitem` VALUES ('39', '35', '13', '25.00', '3');
INSERT INTO `resorderitem` VALUES ('40', '36', '12', '30.00', '4');
INSERT INTO `resorderitem` VALUES ('41', '37', '11', '35.00', '5');
INSERT INTO `resorderitem` VALUES ('42', '38', '12', '40.00', '6');
INSERT INTO `resorderitem` VALUES ('43', '39', '12', '45.00', '7');
INSERT INTO `resorderitem` VALUES ('44', '30', '3', '50.00', '8');
INSERT INTO `resorderitem` VALUES ('45', '31', '4', '55.00', '9');
INSERT INTO `resorderitem` VALUES ('46', '32', '12', '60.00', '10');
INSERT INTO `resorderitem` VALUES ('47', '33', '2', '65.00', '11');
INSERT INTO `resorderitem` VALUES ('48', '34', '4', '20.00', '2');
INSERT INTO `resorderitem` VALUES ('49', '45', '1', '25.00', '3');
INSERT INTO `resorderitem` VALUES ('50', '46', '2', '30.00', '4');
INSERT INTO `resorderitem` VALUES ('51', '47', '3', '35.00', '5');
INSERT INTO `resorderitem` VALUES ('52', '48', '4', '40.00', '6');
INSERT INTO `resorderitem` VALUES ('53', '49', '5', '45.00', '7');
INSERT INTO `resorderitem` VALUES ('54', '50', '6', '50.00', '8');
INSERT INTO `resorderitem` VALUES ('55', '51', '7', '55.00', '9');
INSERT INTO `resorderitem` VALUES ('56', '52', '8', '60.00', '10');
INSERT INTO `resorderitem` VALUES ('57', '53', '9', '65.00', '11');
INSERT INTO `resorderitem` VALUES ('58', '54', '10', '20.00', '2');
INSERT INTO `resorderitem` VALUES ('60', '56', '15', '100.00', '1');
INSERT INTO `resorderitem` VALUES ('61', '57', '15', '100.00', '1');
INSERT INTO `resorderitem` VALUES ('62', '58', '1', '25.00', '3');
INSERT INTO `resorderitem` VALUES ('63', '59', '1', '30.00', '4');
INSERT INTO `resorderitem` VALUES ('64', '60', '1', '35.00', '5');
INSERT INTO `resorderitem` VALUES ('65', '61', '15', '100.00', '1');
INSERT INTO `resorderitem` VALUES ('66', '62', '26', '100.00', '1');

-- ----------------------------
-- Table structure for resticket_user
-- ----------------------------
DROP TABLE IF EXISTS `resticket_user`;
CREATE TABLE `resticket_user` (
  `no` int NOT NULL AUTO_INCREMENT COMMENT '编号',
  `uno` int NOT NULL COMMENT '用户编号',
  `tno` int NOT NULL COMMENT '优惠券编号',
  `fullmoney` decimal(10,2) DEFAULT NULL COMMENT '需达到的金额（作用于满减类型的券）',
  `money` decimal(10,2) DEFAULT NULL COMMENT '可抵扣的金额',
  `type` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT NULL COMMENT '类型（无门槛、满减）',
  `state` int DEFAULT NULL COMMENT '状态（1 已使用 0 未使用）',
  `gettime` date DEFAULT NULL COMMENT '到手时间',
  `overtime` date DEFAULT NULL,
  PRIMARY KEY (`no`) USING BTREE,
  KEY `ticket_fk_resticket` (`tno`) USING BTREE,
  KEY `user_fk_resticket` (`uno`) USING BTREE,
  CONSTRAINT `ticket_fk_resticket` FOREIGN KEY (`tno`) REFERENCES `ticket` (`tno`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `user_fk_resticket` FOREIGN KEY (`uno`) REFERENCES `resuser` (`userid`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=317 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of resticket_user
-- ----------------------------
INSERT INTO `resticket_user` VALUES ('304', '2', '5', '0.00', '1.23', '无门槛券', '0', '2024-01-04', '2024-02-04');
INSERT INTO `resticket_user` VALUES ('305', '2', '6', '0.00', '0.15', '无门槛券', '0', '2024-01-04', '2024-02-04');
INSERT INTO `resticket_user` VALUES ('307', '3', '6', '0.00', '1.94', '无门槛券', '0', '2024-01-04', '2024-02-04');
INSERT INTO `resticket_user` VALUES ('310', '2', '8', '0.00', '0.48', '无门槛券', '0', '2024-01-04', '2024-02-04');
INSERT INTO `resticket_user` VALUES ('311', '1', '9', '0.00', '41.67', '无门槛券', '0', '2024-01-04', '2024-02-04');
INSERT INTO `resticket_user` VALUES ('312', '2', '9', '0.00', '105.80', '无门槛券', '0', '2024-01-04', '2024-02-04');
INSERT INTO `resticket_user` VALUES ('313', '4', '9', '0.00', '8.45', '无门槛券', '0', '2024-01-04', '2024-02-04');
INSERT INTO `resticket_user` VALUES ('314', '1', '10', '0.00', '1.00', '无门槛券', '0', '2024-01-05', '2024-02-05');
INSERT INTO `resticket_user` VALUES ('315', '1', '11', '0.00', '1.00', '无门槛券', '0', '2024-01-05', '2024-02-05');
INSERT INTO `resticket_user` VALUES ('316', '2', '12', '0.00', '1.00', '无门槛券', '0', '2024-01-05', '2024-02-05');

-- ----------------------------
-- Table structure for resuser
-- ----------------------------
DROP TABLE IF EXISTS `resuser`;
CREATE TABLE `resuser` (
  `userid` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) COLLATE utf8mb4_bin DEFAULT NULL,
  `pwd` varchar(150) COLLATE utf8mb4_bin DEFAULT NULL,
  `email` varchar(500) COLLATE utf8mb4_bin DEFAULT NULL,
  `status` varchar(2) COLLATE utf8mb4_bin DEFAULT '0',
  `lastonline` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`userid`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

-- ----------------------------
-- Records of resuser
-- ----------------------------
INSERT INTO `resuser` VALUES ('1', 'a', '0cc175b9c0f1b6a831c399e269772661', 'a@163.com', '1', '2024-01-05 14:32:15.000000');
INSERT INTO `resuser` VALUES ('2', 'b', '0cc175b9c0f1b6a831c399e269772661', 'b@163.com', '0', '2024-01-05 14:32:41.000000');
INSERT INTO `resuser` VALUES ('3', 'c', '0cc175b9c0f1b6a831c399e269772661', 'b@163.com', '0', '2024-01-03 21:11:57.000000');
INSERT INTO `resuser` VALUES ('4', 'd', '0cc175b9c0f1b6a831c399e269772661', 'c@163.com', '0', '2024-01-04 21:41:09.000000');

-- ----------------------------
-- Table structure for ticket
-- ----------------------------
DROP TABLE IF EXISTS `ticket`;
CREATE TABLE `ticket` (
  `tno` int NOT NULL AUTO_INCREMENT COMMENT '优惠券编号',
  `fullmoney` decimal(10,2) DEFAULT NULL COMMENT '如果为满减券，则需要满足这个金额才能使用。无门槛可忽略',
  `money` decimal(10,2) DEFAULT NULL COMMENT '总金额',
  `ticketcount` int DEFAULT NULL COMMENT '数量',
  `type` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT NULL COMMENT '类型（无门槛、满减）',
  `starttime` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT NULL COMMENT '开始时间',
  `endtime` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT NULL COMMENT '结束时间',
  `remainmoney` decimal(10,2) DEFAULT NULL COMMENT '剩余金额',
  `remainticket` int DEFAULT NULL COMMENT '剩余优惠券数',
  `state` int DEFAULT NULL COMMENT '是否结束（1 正在进行中  0 已结束）',
  PRIMARY KEY (`tno`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of ticket
-- ----------------------------
INSERT INTO `ticket` VALUES ('1', '0.00', '1000.00', '800', '无门槛券', '2023-12-28 0:0:0', '2023-12-29 0:0:0', '1000.00', '800', '0');
INSERT INTO `ticket` VALUES ('4', '0.00', '10000.00', '6000', '无门槛券', '2023-12-28 0:0:0', '2023-12-29 0:0:0', '8497.00', '5097', '0');
INSERT INTO `ticket` VALUES ('5', '0.00', '6000.00', '4000', '无门槛券', '2023-12-30 0:0:0', '2024-1-1 0:0:0', '5998.00', '3998', '0');
INSERT INTO `ticket` VALUES ('6', '0.00', '10.00', '10', '无门槛券', '2024-1-2 0:0:0', '2024-1-3 0:0:0', '7.32', '7', '0');
INSERT INTO `ticket` VALUES ('7', '0.00', '1.00', '1', '无门槛券', '2024-1-3 0:0:0', '2024-1-4 0:0:0', '0.00', '0', '0');
INSERT INTO `ticket` VALUES ('8', '0.00', '1.00', '2', '无门槛券', '2024-1-4 0:0:0', '2024-1-5 0:0:0', '0.00', '0', '0');
INSERT INTO `ticket` VALUES ('9', '0.00', '1233.00', '12', '无门槛券', '2024-1-4 13:0:0', '2024-1-5 13:0:0', '1077.08', '9', '0');
INSERT INTO `ticket` VALUES ('10', '0.00', '1.00', '1', '无门槛券', '2024-1-5 0:0:0', '2024-1-6 0:0:0', '0.00', '0', '0');
INSERT INTO `ticket` VALUES ('11', '0.00', '1.00', '1', '无门槛券', '2024-1-5 0:0:0', '2024-1-6 0:0:0', '0.00', '0', '0');
INSERT INTO `ticket` VALUES ('12', '0.00', '1.00', '1', '无门槛券', '2024-1-5 0:0:0', '2024-1-6 0:0:0', '0.00', '0', '0');
